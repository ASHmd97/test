declare const resources: {
    ar: {
        sailor_gundam_nps_machpro: {
            locale: string;
            version: number;
            test111: string;
        };
    };
    en: {
        sailor_gundam_nps_machpro: {
            locale: string;
            version: number;
            test111: string;
        };
    };
    zh: {
        sailor_gundam_nps_machpro: {
            locale: string;
            version: number;
            test111: string;
        };
    };
    'zh-CN': {
        sailor_gundam_nps_machpro: {
            locale: string;
            version: number;
            test111: string;
        };
    };
    'zh-HK': {
        sailor_gundam_nps_machpro: {
            locale: string;
            version: number;
            test111: string;
        };
    };
};
export default resources;
